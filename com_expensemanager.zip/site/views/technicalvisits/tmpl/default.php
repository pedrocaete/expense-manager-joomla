<div class="technical-visit">
    <h1 class="com_sagp-title"><?php echo JText::_('COM_EXPENSEMANAGER_TECHNICALVISIT_LIST_TITLE'); ?></h1>

    <div class="download-button">
        <a href="<?php echo $pdfUrlAll; ?>" target="_blank" class="com_sagp-button">
            <span class="icon-download" aria-hidden="true"></span>
            Baixar Relatório Geral
        </a>
    </div>

    <form action="<?php echo JRoute::_('index.php?option=com_expensemanager&view=technicalvisits'); ?>" method="post" name="adminForm" id="adminForm">
        <div class="list">

            <div class="grid-table header">
                <div>ID</div>
                <div>Data da Visita</div>
                <div>Cliente</div>
                <div>Consultores Associados</div>
                <div class="text-center">Ação</div>
            </div>

            <?php if (!empty($this->items)) : ?>
                <?php foreach ($this->items as $i => $item) : ?>
                    <?php
                    $pdfUrlIndividual = JRoute::_('index.php?option=com_expensemanager&view=technicalvisit&id=' . (int) $item->id . '&format=pdf');
                    ?>
                    <div class="grid-table row">
                        <div><?php echo $item->id; ?></div>
                        <div><?php echo JHtml::_('date', $item->visit_date, 'd/m/Y'); ?></div>
                        <div><?php echo $this->escape($item->client_name); ?></div>
                        <div><?php echo $this->escape($item->consultants); ?></div>
                        <div class="text-center">
                            <a href="<?php echo $pdfUrlIndividual; ?>" class="com_sagp-button" target="_blank">
                                <span class="icon-file" aria-hidden="true"></span>
                                Gerar PDF
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="grid-table empty">
                    <div class="no-data" style="grid-column: 1 / -1; text-align: center;">
                        Nenhuma visita técnica encontrada.
                    </div>
                </div>
            <?php endif; ?>

            <div class="grid-table footer">
                <div style="grid-column: 1 / -1;">
                    <?php echo $this->pagination->getListFooter(); ?>
                </div>
            </div>

            <div>
                <input type="hidden" name="task" value="" />
                <?php echo JHtml::_('form.token'); ?>
            </div>
        </div>
    </form>
</div>
