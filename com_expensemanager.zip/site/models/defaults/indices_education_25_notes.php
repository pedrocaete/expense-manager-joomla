<?php defined('_JEXEC') or die; ?>
<p>Considerando-se o disposto na “Instrução Normativa nº 02/2021, do Tribunal de Contas do Estado de Minas Gerais”, atualizada pela INTCE nº 01/2023, sobre a aplicação de recursos provenientes da arrecadação de impostos e das transferências constitucionais na manutenção e desenvolvimento do ensino público, analisamos as despesas realizadas na Função 12 - Educação e a efetiva receita resultante de impostos e transferências, em conformidade com os Demonstrativos da Aplicação na Manutenção e Desenvolvimento do Ensino – RREO, até o mês de [MÊS] de [ANO].</p>
<table class="table table-bordered" style="width: 100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Demonstração do Ensino 25%</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">%</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">VALOR (R$)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Total das Receitas de Impostos e Transferências Constitucionais</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Valor Legal Mínimo (art. 212, da CF/88)</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">25,00</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Aplicação na Manutenção e Desenvolvimento do Ensino EMPENHADO</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Aplicação na Manutenção e Desenvolvimento do Ensino LIQUIDADO</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Aplicação na Manutenção e Desenvolvimento do Ensino PAGO</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Diferença Entre Valor EMPENHADO e o Limite Constitucional</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Diferença Entre Valor LIQUIDADO e o Limite Constitucional</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Diferença Entre Valor PAGO e o Limite Constitucional</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
    </tbody>
</table>