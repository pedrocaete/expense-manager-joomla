<?php defined('_JEXEC') or die; ?>
<table class="table table-bordered" style="width: 100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Apuração Cumprimento do Limite Legal</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Valor</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">% Sobre RCL Ajustada</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">RCL - Receita Corrente Liquida Ajustada</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Limite Máximo - 60%</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Despesa Empenhada</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Despesa Liquidada</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Despesa Paga</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
    </tbody>
</table>
