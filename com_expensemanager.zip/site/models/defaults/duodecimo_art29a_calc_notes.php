<?php defined('_JEXEC') or die; ?>
<p>Para fins de aplicação dos limites previstos no art. 29-A, procedemos à apuração das receitas efetivamente arrecadadas pelo município no exercício anterior, tendo como referência de dados o portal fiscalizando com o TCE e do sistema operacional utilizado no município, vejamos:</p>
<table class="table table-bordered" style="width: 100%; border-collapse: collapse;">
    <tbody>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">I. RECEITA TRIBUTÁRIA MUNICIPAL: Impostos (IPTU, IRRF, ITBI e ISSQN), Taxas, Contribuições de Melhoria, Juros e Multas das receitas tributárias, Receita da Dívida Ativa Tributária, juros e multas da dívida ativa tributária;</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">II. RECEITA DE TRANSFERÊNCIAS CONSTITUCIONAIS: IOF sobre o ouro (§5º, Art. 153), IRRF,IPI, ITR, IPVA e ICMS (Art. 158), FPM e CIDE (Art. 159).</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;"><strong>Total</strong></td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">III- Deduções ) 91 - Renúncia, 92 - Restituições, 93 – Descontos Concedidos, 96 - Compensações, 98 - Retificações e 99 – Outras Deduções).</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;"><strong>Base de Cálculo Artigo 29A IV= (I+II-III)</strong></td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Limite 7% - Município com população de até 100.000 habitantes</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Orçamento Fixado para o Exercício de [ANO]</td>
            <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">&nbsp;</td>
        </tr>
    </tbody>
</table>
