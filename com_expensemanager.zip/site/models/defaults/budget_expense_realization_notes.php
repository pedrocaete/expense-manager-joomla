<?php
defined('_JEXEC') or die;
?>
<table class="table table-bordered" style="width: 100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Dotação Atualizada</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Empenhada</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Liquidada</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Paga</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
    </tbody>
</table>