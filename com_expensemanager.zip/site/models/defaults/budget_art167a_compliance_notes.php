<?php defined('_JEXEC') or die; ?>
<table class="table table-bordered" style="width: 100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Receita Corrente</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Valor</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">% sobre receita corrente</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Limite Máximo</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Despesa Corrente</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
            <td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>
        </tr>
    </tbody>
</table>
